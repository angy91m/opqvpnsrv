#!/bin/sh
SELF_PATH=$(dirname "$(realpath "$0")")
cp -r "$SELF_PATH/opqvpnsrvd.d" /bin/opqvpnsrvd.d
cp -r "$SELF_PATH/opqvpnsrvd-console.d" /bin/opqvpnsrvd-console.d
ln -s /bin/opqvpnsrvd.d/opqvpnsrvd /bin/opqvpnsrvd
ln -s /bin/opqvpnsrvd-console.d/opqvpnsrvd-console /bin/opq-vpn-server